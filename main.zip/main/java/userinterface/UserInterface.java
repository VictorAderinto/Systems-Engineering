/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package userinterface;

/**
 *
 * @author semil
 */
public interface UserInterface {
    public abstract void update(String theMessage);
}
