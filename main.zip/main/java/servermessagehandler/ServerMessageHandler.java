/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package servermessagehandler;

import java.io.IOException;


/**
 *
 * @author ferens
 */
public class ServerMessageHandler {
    
    String output = " ";
    client.Client myClient;
    int count = 0;

    public ServerMessageHandler(client.Client myClient) {
        this.myClient = myClient;
    }
    
    public void handleServerMessage(String theCommand) {
        
        if (theCommand.charAt(0)!=0xFFFF) { //Character.toString((char(-1)) = 0xFFFF
            
            output += theCommand;
        } 
        else {
            handleFinalMessage(output);
        }
        
    }
    
    public void handleServerMessage(IOException e) {
        
        myClient.sendMessageToUI("IOException " + e.toString() + " Stopping thread and disconnecting server");
        
    }
    
    public void handleFinalMessage(String theCommand) {
        
        myClient.sendMessageToUI(theCommand);
        output = " ";
    }
}