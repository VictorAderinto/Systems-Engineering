//package com.example.gui;
//
//import static com.example.gui.R.layout.fragment_first;
//
//import android.os.Bundle;
//
//import com.google.android.material.snackbar.Snackbar;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.view.View;
//
//import androidx.appcompat.app.AppCompatActivity;
//import androidx.navigation.NavController;
//import androidx.navigation.Navigation;
//import androidx.navigation.ui.AppBarConfiguration;
//import androidx.navigation.ui.NavigationUI;
//
//import com.example.gui.databinding.ActivityMainBinding;
//
//import android.view.Menu;
//import android.view.MenuItem;
//import android.widget.Button;
//import android.widget.EditText;
//
//public class MainActivity extends AppCompatActivity {
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(fragment_first);
//    }
//
//    public void updatePortNumberButtonHandler(View view) {
//        EditText portNumberText= (EditText) findViewById(R.id.portNumberTextField);
//        String portNumber = portNumberText.getText().toString();
//        EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
//        myServerMessageWindow.append("\nServer port #: " + portNumber.toString());
//    }
//
//}

package com.example.gui;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Switch;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.gui.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements userinterface.UserInterface{

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    String portNumber = "";
    String serverAddress = "";
    TextView myMessageWindow;
    usercommandhandler.UserCommandHandler myUserCommandHandler;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);

        myMessageWindow = (TextView) findViewById(R.id.messageWindow);
        client.Client myClient = new client.Client((int) 7777, (String) "10.0.0.2", this);
        myUserCommandHandler = new usercommandhandler.UserCommandHandler(this, myClient);

        binding.fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        findViewById(R.id.updatePortNumber).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText portNumberText= (EditText) findViewById(R.id.portNumberTextField);
                portNumber = portNumberText.getText().toString();
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                myServerMessageWindow.append("\nServer port #: " + portNumber.toString());
                myUserCommandHandler.handleUserCommand("5 " + portNumber.toString());
            }
        });
        findViewById(R.id.updateServerAddress).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText serverAdressText= (EditText) findViewById(R.id.serverAddressTextField);
                serverAddress = serverAdressText.getText().toString();
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                myServerMessageWindow.append("\nServer Address: " + serverAddress.toString());
                myUserCommandHandler.handleUserCommand("6 "+ serverAddress.toString());
            }
        });
        findViewById(R.id.connectToServer).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                myServerMessageWindow.append("\nConnected to Server on port: " + portNumber.toString());
                myUserCommandHandler.handleUserCommand("2");
            }
        });
        findViewById(R.id.disconnectFromServer).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                myServerMessageWindow.append("\nDisconnected from Server on port: " + portNumber.toString());
                myUserCommandHandler.handleUserCommand("3");
            }
        });
        findViewById(R.id.pB1Button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                myServerMessageWindow.append("\nRequesting push button1 state from server");
                myUserCommandHandler.handleUserCommand("4 " + "gpb1");
            }
        });
        findViewById(R.id.pB2utton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                myServerMessageWindow.append("\nRequesting push button2 state from server");
                myUserCommandHandler.handleUserCommand("4 " + "gpb3");
            }
        });
        findViewById(R.id.getTimeButton).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                myServerMessageWindow.append("\nRequesting time from the server");
                myUserCommandHandler.handleUserCommand("4 " + "t");
            }
        });
        findViewById(R.id.pB3Button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                myServerMessageWindow.append("\nRequesting push button3 state from server");
                myUserCommandHandler.handleUserCommand("4 " + "gpb3");
            }
        });

        final Switch sw1 = (Switch) findViewById(R.id.LED1Switch);
        sw1.setOnCheckedChangeListener (new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                if (isChecked) {
                    myUserCommandHandler.handleUserCommand("4 " + "L1on");
                    myServerMessageWindow.append("\nLED1 is on");
                } else {
                    myUserCommandHandler.handleUserCommand("4 " + "L1off");
                    myServerMessageWindow.append("\nLED1 is off");
                }
            }
        });
        final Switch sw2 = (Switch) findViewById(R.id.LED2Switch);
        sw2.setOnCheckedChangeListener (new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                if (isChecked) {
                    myUserCommandHandler.handleUserCommand("4 " + "L2on");
                    myServerMessageWindow.append("\nLED2 is on");
                } else {
                    myUserCommandHandler.handleUserCommand("4 " + "L2off");
                    myServerMessageWindow.append("\nLED2 is off");
                }
            }
        });
        final Switch sw3 = (Switch) findViewById(R.id.LED3Switch);
        sw3.setOnCheckedChangeListener (new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                if (isChecked) {
                    myUserCommandHandler.handleUserCommand("4 " + "L3on");
                    myServerMessageWindow.append("\nLED3 is on");
                } else {
                    myUserCommandHandler.handleUserCommand("4 " + "L3off");
                    myServerMessageWindow.append("\nLED3 is off");
                }
            }
        });
        final Switch sw4 = (Switch) findViewById(R.id.LED4Switch);
        sw4.setOnCheckedChangeListener (new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                EditText myServerMessageWindow = (EditText) findViewById(R.id.messageWindow);
                if (isChecked) {
                    myUserCommandHandler.handleUserCommand("4 " + "L4on");
                    myServerMessageWindow.append("\nLED4 is on");
                } else {
                    myUserCommandHandler.handleUserCommand("4 " + "L4off");
                    myServerMessageWindow.append("\nLED4 is off");
                }
            }
        });

    }
    public void update(String theString) {
        Message msg = Message.obtain();
        msg.obj = theString;
        handler.sendMessage(msg);
    }

    Handler handler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            myMessageWindow.append("\n" + msg.obj.toString());
        }
    };

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        // Handle action bar item clicks here. The action bar will
//        // automatically handle clicks on the Home/Up button, so long
//        // as you specify a parent activity in AndroidManifest.xml.
//        int id = item.getItemId();
//
//        //noinspection SimplifiableIfStatement
//        if (id == R.id.action_settings) {
//            return true;
//        }
//
//        return super.onOptionsItemSelected(item);
//    }
//
//    @Override
//    public boolean onSupportNavigateUp() {
//        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
//        return NavigationUI.navigateUp(navController, appBarConfiguration)
//                || super.onSupportNavigateUp();
//    }
}