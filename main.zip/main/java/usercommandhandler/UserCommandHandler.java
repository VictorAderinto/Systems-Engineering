/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package usercommandhandler;

/**
 *
 * @author ferens
 */
public class UserCommandHandler implements Runnable {
    userinterface.UserInterface myUI;
    client.Client myClient;
    String theCommand = "";

    public UserCommandHandler(userinterface.UserInterface myUI, client.Client myClient) {
        this.myUI = myUI;
        this.myClient = myClient;
    }
    
    public void handleUserCommand(String theCommand){
        this.theCommand = theCommand;
        Thread myCommandThread = new Thread(this);
        myCommandThread.start();
    }

    public void run() {
        
        int switchCase = Integer.parseInt(theCommand.split(" ")[0]);
        switch (switchCase) {
            case 2: //START & CONNECT TO SERVER SOCKET
                myClient.connectToServer();
                myUI.update("Connection to Server Socket has been created.");
                break;
            case 3: //DISCONNECT FROM SERVER
                myClient.disconnectFromServer();
                myUI.update("Disconnected from Server, ...");
                break;
            case 1: //QUIT
                myClient.stopThread();
                myUI.update("Quiting program by User command.");
                System.exit(0);
                break;
            case 4: //SEND MESSAGE
                myClient.sendMessageToServer(theCommand.split(" ")[1]);
                myUI.update("Sending message to the server");
                break;
            case 5: //SET PORT
                String portString = theCommand.split(" ")[1];
                int portNumber = Integer.parseInt(portString);
                myClient.setPort(portNumber);
                myUI.update("Port number has been set to " + portNumber);
                break;
            case 6: //SET ADDRESS
                String host = theCommand.split(" ")[1];
                myClient.setHost(host);
                myUI.update("Socket Adress has been set to " + host);
                break;
            default:
                break;
        }
    }
}
