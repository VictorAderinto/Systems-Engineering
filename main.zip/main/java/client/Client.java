


package client;

import java.io.*;
import java.net.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Client implements Runnable {

    InputStream input;
    OutputStream output;
    ServerSocket ServerSocket = null;
    Socket ClientSocket = null;
    servermessagehandler.ServerMessageHandler myServerMessageHandler;
    userinterface.UserInterface myUI;
    int portNumber = 5555, backlog = 100;
    boolean connected = false;
    boolean stopThread = false;
    String host = "";


//    public Client(int portNumber, int backlog, userinterface.UserInterface myUI) {
//        this.portNumber = portNumber;
//        this.backlog = backlog;
//        this.myUI = myUI;
//        this.myServerMessageHandler = new servermessagehandler.ServerMessageHandler(this);
//     }
    public Client(int portNumber, String host, userinterface.UserInterface myUI) {
        this.portNumber = portNumber;
        this.myUI = myUI;
        this.host = host;
        this.myServerMessageHandler = new servermessagehandler.ServerMessageHandler(this);
    }

    public void connectToServer() {
        if (ClientSocket != null) {
            sendMessageToUI("Client socket has already been created.");
        } else {
            try {
                ClientSocket = new Socket(host, portNumber);
                output = ClientSocket.getOutputStream();
                input = ClientSocket.getInputStream();
                Thread myClientThread = new Thread(this);
                myClientThread.start();
                stopThread = false;
                connected = true;
            } catch (IOException e) {
                sendMessageToUI("Cannot create "
                        + "ClientSocket, because " 
                        + e +". Exiting program.");
                System.exit(0);
            } finally {
            }
        }
    }

    public void disconnectFromServer() {
        if (ClientSocket != null) {
            byte msg = (byte) 'd';
            try {
                output.write(msg);
                output.flush();
                protocolMessage();
                stopThread();
                connected = false;
                ClientSocket.close();
                ClientSocket = null;
            } catch (IOException e) {
                sendMessageToUI("Cannot close ClientSocket, because " + e +". Exiting program.");
                System.exit(0);
            } finally {
            }

        }
    }

    public void sendMessageToServer(String theCommand) {
        if (ClientSocket != null) {
            try {
                for (int i = 0; i < theCommand.length(); i++)
                {
                    output.write(theCommand.charAt(i));
                    output.flush();
                }
                protocolMessage();
            } catch (IOException e) {
                sendMessageToUI("Cannot send message to server, because " + e +". Exiting program.");
                System.exit(0);
            } finally {
            }

        }
    }
    
    public void protocolMessage(){   
        try {
            output.write((byte) 0xFF);
            output.flush();
        } catch (IOException e) {
            sendMessageToUI("Cannot send message to server, because " + e +". Exiting program.");
            System.exit(0);
        }
    }
    
    public void setPort(int portNumber) {
        this.portNumber = portNumber;
    }
   
    public void setHost(String host){
        this.host = host;
    }

    public int getPort() {
        return this.portNumber;
    }
    
    public boolean isConnected() {
        return connected;
    }

    public void stopThread() {
        stopThread = true;
    }    

    @Override
    public void run() {
        byte msg;
        String theString;
        while (true) {
            if (stopThread == false) {
                try {
                    msg = (byte) input.read();
                    theString = Character.toString((char)msg);
                    myServerMessageHandler.handleServerMessage(theString);
                } catch (IOException e) {
                    myServerMessageHandler.handleServerMessage(e);
                } finally {
                }
            } 
            else {
                try {
                    Thread.sleep(500);
                } catch (InterruptedException ie) {}
            }
        }
    }
//     
    public void sendMessageToUI(String theString) {
        myUI.update(theString);
    }
}